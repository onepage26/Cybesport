<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Login</title>
		<link rel="stylesheet" href="style.css">
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	</head>
	<body>   
		<form method="post" class="box" action="login1.php">
			<h1><a class="form_link" href="http://localhost/News.php">Log In</a></h1>

            <div class="input-box">
			    <input type="text" name ="login" placeholder="Username" required>
                <i class='bx bx-user' ></i>
            </div>

            <div class="input-box">
			    <input type="password" name ="pass" placeholder="Password" required>
                <a href="#" class="password-control" onclick="return show_hide_password(this);"></a>
            </div>

            <div class="remember">
                <label for=""><input type="checkbox">Remember me</input></label>
                <a href="#">Forgot Password?</a>
            </div>
        
		    <input type="submit" name="submit" value="Login">

            <div class="register-link">
                <p>Don't have an account?<a href="http://localhost/regis.php"> Register</a></p>
            </div>
		</form>	
	</body>
</html>