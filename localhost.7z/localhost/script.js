let offset=0;
const sliderLine = document.querySelector('.slider-line');

document.querySelector('.next-button').addEventListener('click', function(){
    offset = offset + 200;
    if (offset > 1000) {
        offset = 0;
    }
    sliderLine.style.left = -offset + 'px';
});

document.querySelector('.prev-button').addEventListener('click', function () {
    offset = offset - 200;
    if (offset < 0) {
        offset = 1000;
    }
    sliderLine.style.left = -offset + 'px';
});


function openWhatsAppChat() {
    const phoneNumber = document.querySelector(".field[placeholder='Phone']").value;
  
    const whatsappChatLink = `https://wa.me/${+7751272537}`;
  
    window.open(whatsappChatLink, "_blank");
  }

  function send_handle() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let num = document.getElementById("number").value;
    let msg = document.getElementById("msg").value;
    const number = '+7751272537';

    // Откройте новую веб-страницу в новом окне браузера.
  const newWindow = window.open("", "_blank");
  newWindow.document.write(newHtmlPage);
}


