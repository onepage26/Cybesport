<?php
require_once("db.php");

// Проверка аутентификации пользователя
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];

// Запрос для получения информации о пользователе и его профиле
$query = "SELECT users.*, profiles.* FROM users
          LEFT JOIN profiles ON users.id = profiles.user_id
          WHERE users.id = $user_id";
$result = $conn->query($query);

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    // Отобразите информацию о пользователе и его профиле
    echo "Имя пользователя: " . $row["login"] . "<br>";
    echo "Email: " . $row["email"] . "<br>";
    echo "Полное имя: " . $row["full_name"] . "<br>";
    echo "Биография: " . $row["bio"] . "<br>";
    echo "<img src='" . $row["profile_image"] . "' alt='Фото профиля'>";
} else {
    echo "Профиль не найден";
}

