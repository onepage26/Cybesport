<?php
 require_once("db1.php");

if (isset($_POST["submit"])) {
   $name = $_POST['name'];
   $email = $_POST['email'];
   $number = $_POST['number'];
   $msg = $_POST['msg'];

   $sql = "INSERT INTO `crud` (name,email,number,msg) VALUES ('$name','$email','$number','$msg')";
    

   $result = mysqli_query($conn, $sql);

    if($result->num_rows === 1){
        while($row=$result->fetch_assoc()){
            header("Location: http://localhost/News.php");
        }
    } else {
      echo "Failed: " . mysqli_error($conn);
   }
}

?>