<?php
require_once("db1.php");
$id = $_GET["id"];
$sql = "DELETE FROM `crud` WHERE id = $id";
$result = mysqli_query($conn, $sql);

if ($result) {
  header("Location: News.php");
} else {
  echo "Failed: " . mysqli_error($conn);
}